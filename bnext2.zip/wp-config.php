<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
#define('WP_CACHE', true);
#define( 'WPCACHEHOME', '/var/www/html/bnext2/wp-content/plugins/wp-super-cache/' );
define('DB_NAME', 'project_bnext2');

/** MySQL database username */
define('DB_USER', 'joroni');

/** MySQL database password */
define('DB_PASSWORD', '!iLoveus1!');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');



define( 'WPMS_ON', true );
define( 'WPMS_SMTP_PASS', 'iloveus1!' );
/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'w0R2sKBET?}]NE{b((.P4?Ku#ywHFSJG: >qaF:<.k7@t+5P6m>ks(bev V4R*#M');
define('SECURE_AUTH_KEY',  'Cn)*d~B&@B5*v{B5UGij_m_>qjS.i(l!f@Hcd~`~/wO~bir{piPRIJN^dr?1rAVt');
define('LOGGED_IN_KEY',    'c^BGO>!j{7D +&FC#/Wa~+X{8e**WK*f~h?(VyL6nadZpj7*CqM I.z8f-^1$3(2');
define('NONCE_KEY',        'KpoHT0z1JQFe+%&bQQzejl*Y26_iKn>;Va$3>-:y$No}nmbKMA>*2[kVlKd!l{6Q');
define('AUTH_SALT',        'Og98(z(Ub+:j9kVAt8Xc<z:H=(||/x<;aG8eOqM6qsz5QRTVbZ4*W9RkDANUiV:;');
define('SECURE_AUTH_SALT', ' cr7KM5m`;&yCDD13cG?9]bXT^MDrSV.xg<NOg9i1YV%i/1M8NTxdnTV|_0ibXvl');
define('LOGGED_IN_SALT',   '!k(5n2mvgxpbW T3v6ZYZ3Nz0?GbV7wMVd=pq:}M jW6j:<YLViet.;9d$dl47&K');
define('NONCE_SALT',       'xc}6Yb9[w2bQl<AAm~_z[EDvD[H+2L${x!9u}?#$euRUtGZ:pT+nNwzDL6.3#( Y');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
